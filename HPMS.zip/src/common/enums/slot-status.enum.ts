export enum SlotStatus {
    AVAILABLE = 'AVAILABLE',
    BOOKED = 'BOOKED',
}

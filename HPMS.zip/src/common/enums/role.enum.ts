export enum Role {
    SUPER_ADMIN = 'SUPER_ADMIN', // Hospital Owner
    ADMIN = 'admin',  // Doctor / Staff
    USER = 'user',  // Patient
}

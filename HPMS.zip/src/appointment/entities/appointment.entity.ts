export class Appointment {}
